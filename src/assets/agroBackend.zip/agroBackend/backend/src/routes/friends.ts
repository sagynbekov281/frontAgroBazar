import { Router } from 'express';
import { nanoid } from 'nanoid';
import { readDb, writeDb, DbUser } from '../db';
import { auth, AR } from '../middleware/auth';
import { emitToUser } from '../socket';

const r = Router();

const pubUser = (u: DbUser) => ({ id: u.id, name: u.name, phone: u.phone, role: u.role, region: u.region, rating: u.rating, verified: u.verified, online: !!u.online, lastSeen: u.lastSeen });

/* ── Поиск пользователей (чтобы добавить в друзья) по имени/телефону/email ── */
r.get('/search', auth, (req: AR, res) => {
  const q = String(req.query.q || '').trim().toLowerCase();
  if (!q) return res.json({ users: [] });
  const db = readDb();
  const results = db.users
    .filter(u => u.id !== req.userId)
    .filter(u => u.name.toLowerCase().includes(q) || u.phone.includes(q) || u.email.toLowerCase().includes(q))
    .slice(0, 20)
    .map(pubUser);
  res.json({ users: results });
});

/* ── Список моих друзей с онлайн-статусом ── */
r.get('/', auth, (req: AR, res) => {
  const db = readDb();
  const me = db.users.find(u => u.id === req.userId);
  if (!me) return res.status(401).json({ message: 'Авторизация талап кылынат' });
  const friends = (me.friends || [])
    .map(fid => db.users.find(u => u.id === fid))
    .filter((u): u is DbUser => !!u)
    .map(pubUser);
  res.json({ friends });
});

/* ── Входящие заявки в друзья ── */
r.get('/requests', auth, (req: AR, res) => {
  const db = readDb();
  const incoming = db.friendRequests.filter(fr => fr.toId === req.userId && fr.status === 'pending');
  res.json({ requests: incoming });
});

/* ── Мои отправленные заявки (чтобы фронт показал "заявка отправлена") ── */
r.get('/requests/sent', auth, (req: AR, res) => {
  const db = readDb();
  const sent = db.friendRequests.filter(fr => fr.fromId === req.userId && fr.status === 'pending');
  res.json({ requests: sent });
});

/* ── Отправить заявку в друзья ── */
r.post('/requests', auth, (req: AR, res) => {
  const db = readDb();
  const me = db.users.find(u => u.id === req.userId);
  const other = db.users.find(u => u.id === req.body.toId);
  if (!me) return res.status(401).json({ message: 'Авторизация талап кылынат' });
  if (!other) return res.status(404).json({ message: 'Колдонуучу табылган жок' });
  if (other.id === me.id) return res.status(400).json({ message: 'Өзүңүздү кошо албайсыз' });
  if ((me.friends || []).includes(other.id)) return res.status(409).json({ message: 'Бул колдонуучу мурунтан эле досуңуз' });
  const existing = db.friendRequests.find(fr => fr.status === 'pending' && ((fr.fromId === me.id && fr.toId === other.id) || (fr.fromId === other.id && fr.toId === me.id)));
  if (existing) return res.status(409).json({ message: 'Сурам мурунтан эле жиберилген' });
  const request = { id: nanoid(), fromId: me.id, fromName: me.name, toId: other.id, toName: other.name, status: 'pending' as const, createdAt: new Date().toISOString() };
  db.friendRequests.push(request); writeDb(db);
  emitToUser(other.id, 'friend_request_received', request);
  res.status(201).json({ request });
});

/* ── Принять заявку ── */
r.post('/requests/:id/accept', auth, (req: AR, res) => {
  const db = readDb();
  const request = db.friendRequests.find(fr => fr.id === req.params.id);
  if (!request) return res.status(404).json({ message: 'Сурам табылган жок' });
  if (request.toId !== req.userId) return res.status(403).json({ message: 'Укук жок' });
  if (request.status !== 'pending') return res.status(409).json({ message: 'Сурам мурунтан эле каралган' });
  request.status = 'accepted';
  const me = db.users.find(u => u.id === request.toId);
  const other = db.users.find(u => u.id === request.fromId);
  if (me && other) {
    me.friends = me.friends || []; if (!me.friends.includes(other.id)) me.friends.push(other.id);
    other.friends = other.friends || []; if (!other.friends.includes(me.id)) other.friends.push(me.id);
  }
  writeDb(db);
  if (me) emitToUser(request.fromId, 'friend_request_accepted', { by: { id: me.id, name: me.name } });
  res.json({ success: true });
});

/* ── Отклонить заявку ── */
r.post('/requests/:id/decline', auth, (req: AR, res) => {
  const db = readDb();
  const request = db.friendRequests.find(fr => fr.id === req.params.id);
  if (!request) return res.status(404).json({ message: 'Сурам табылган жок' });
  if (request.toId !== req.userId) return res.status(403).json({ message: 'Укук жок' });
  request.status = 'declined'; writeDb(db);
  res.json({ success: true });
});

/* ── Удалить из друзей ── */
r.delete('/:userId', auth, (req: AR, res) => {
  const db = readDb();
  const me = db.users.find(u => u.id === req.userId);
  const other = db.users.find(u => u.id === req.params.userId);
  if (!me) return res.status(401).json({ message: 'Авторизация талап кылынат' });
  if (me.friends) me.friends = me.friends.filter(id => id !== req.params.userId);
  if (other?.friends) other.friends = other.friends.filter(id => id !== me.id);
  writeDb(db);
  if (other) emitToUser(other.id, 'friend_removed', { userId: me.id });
  res.json({ success: true });
});

export default r;
