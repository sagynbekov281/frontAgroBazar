import { Server as IOServer, Socket } from 'socket.io';
import type { Server as HTTPServer } from 'http';
import jwt from 'jsonwebtoken';
import { JWT_SECRET } from './middleware/auth';
import { readDb, writeDb } from './db';

let io: IOServer | null = null;

// userId -> Set socket.id (один пользователь может быть открыт в нескольких вкладках/устройствах)
const onlineSockets = new Map<string, Set<string>>();

export function initSocket(server: HTTPServer) {
  // на старте сервера все "online: true" из старого db.json — устаревшие данные
  // (in-memory карта сокетов всегда пустая после рестарта), поэтому обнуляем
  const bootDb = readDb();
  let bootChanged = false;
  bootDb.users.forEach(u => { if (u.online) { u.online = false; bootChanged = true; } });
  if (bootChanged) writeDb(bootDb);

  io = new IOServer(server, {
    cors: { origin: '*' },
  });

  io.use((socket, next) => {
    const token = socket.handshake.auth?.token as string | undefined;
    if (!token) return next(new Error('Токен талап кылынат'));
    try {
      const payload = jwt.verify(token, JWT_SECRET) as { userId: string };
      socket.data.userId = payload.userId;
      next();
    } catch {
      next(new Error('Токен жараксыз'));
    }
  });

  io.on('connection', (socket: Socket) => {
    const userId: string = socket.data.userId;
    socket.join(`user:${userId}`);

    const set = onlineSockets.get(userId) ?? new Set<string>();
    const wasOffline = set.size === 0;
    set.add(socket.id);
    onlineSockets.set(userId, set);

    const db = readDb();
    const me = db.users.find(u => u.id === userId);

    if (me) {
      if (wasOffline) {
        me.online = true;
        writeDb(db);
        (me.friends || []).forEach(friendId => emitToUser(friendId, 'friend_online', { userId }));
      }
      // сразу при подключении отдаём клиенту текущий онлайн-статус всех его друзей
      const friendsStatus = (me.friends || []).map(fid => {
        const f = db.users.find(u => u.id === fid);
        return { userId: fid, online: !!f?.online, lastSeen: f?.lastSeen };
      });
      socket.emit('friends_status', friendsStatus);
    }

    socket.on('typing', ({ roomId }: { roomId: string }) => {
      const now = readDb();
      const room = now.rooms.find(r => r.id === roomId);
      room?.participants.forEach(p => { if (p.id !== userId) emitToUser(p.id, 'typing', { roomId, userId }); });
    });

    socket.on('stop_typing', ({ roomId }: { roomId: string }) => {
      const now = readDb();
      const room = now.rooms.find(r => r.id === roomId);
      room?.participants.forEach(p => { if (p.id !== userId) emitToUser(p.id, 'stop_typing', { roomId, userId }); });
    });

    socket.on('disconnect', () => {
      const s = onlineSockets.get(userId);
      s?.delete(socket.id);
      if (!s || s.size === 0) {
        onlineSockets.delete(userId);
        const dbNow = readDb();
        const user = dbNow.users.find(u => u.id === userId);
        if (user) {
          user.online = false;
          user.lastSeen = new Date().toISOString();
          writeDb(dbNow);
          (user.friends || []).forEach(friendId => emitToUser(friendId, 'friend_offline', { userId, lastSeen: user.lastSeen }));
        }
      }
    });
  });

  return io;
}

/** Отправить событие конкретному пользователю (во все его открытые вкладки/устройства) */
export function emitToUser(userId: string, event: string, payload: any) {
  io?.to(`user:${userId}`).emit(event, payload);
}

export function isUserOnline(userId: string) {
  return onlineSockets.has(userId);
}
