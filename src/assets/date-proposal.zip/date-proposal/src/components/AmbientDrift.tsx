import { useMemo } from "react";

interface Particle {
  id: number;
  left: number;
  size: number;
  delay: number;
  duration: number;
  driftX: number;
  color: string;
}

const COLORS = ["var(--color-gold)", "var(--color-blush)", "var(--color-gold-soft)"];

export default function AmbientDrift({ count = 18 }: { count?: number }) {
  const particles = useMemo<Particle[]>(
    () =>
      Array.from({ length: count }, (_, id) => ({
        id,
        left: Math.random() * 100,
        size: 3 + Math.random() * 5,
        delay: Math.random() * 10,
        duration: 10 + Math.random() * 10,
        driftX: (Math.random() - 0.5) * 80,
        color: COLORS[id % COLORS.length],
      })),
    [count]
  );

  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {particles.map((p) => (
        <span
          key={p.id}
          style={{
            left: `${p.left}%`,
            bottom: "-5%",
            width: p.size,
            height: p.size,
            backgroundColor: p.color,
            animation: `drift-up ${p.duration}s linear ${p.delay}s infinite`,
            ["--drift-x" as string]: `${p.driftX}px`,
          }}
          className="absolute rounded-full opacity-0 blur-[0.5px]"
        />
      ))}
    </div>
  );
}
