import { useRef, useState, useCallback } from "react";

interface DodgeButtonProps {
  labels: string[];
  className?: string;
}

/**
 * Кнопка, которая физически убегает от курсора и от тапа.
 * Не привязана к какому-либо действию "отказа" — она существует
 * только для того, чтобы её было невозможно поймать.
 */
export default function DodgeButton({ labels, className = "" }: DodgeButtonProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState({ x: 0, y: 0 });
  const [labelIndex, setLabelIndex] = useState(0);
  const [dodgeCount, setDodgeCount] = useState(0);
  const btnRef = useRef<HTMLButtonElement>(null);

  const dodge = useCallback(() => {
    const container = containerRef.current;
    const btn = btnRef.current;
    if (!container || !btn) return;

    const cRect = container.getBoundingClientRect();
    const bRect = btn.getBoundingClientRect();

    const maxX = Math.max(cRect.width - bRect.width, 0);
    const maxY = Math.max(cRect.height - bRect.height, 0);

    // Случайная новая позиция внутри контейнера
    const nextX = Math.random() * maxX;
    const nextY = Math.random() * maxY;

    setPos({ x: nextX, y: nextY });
    setLabelIndex((i) => (i + 1) % labels.length);
    setDodgeCount((c) => c + 1);
  }, [labels.length]);

  return (
    <div
      ref={containerRef}
      className={`relative h-24 sm:h-16 w-full ${className}`}
    >
      <button
        ref={btnRef}
        type="button"
        style={{
          transform: `translate(${pos.x}px, ${pos.y}px)`,
          transition: "transform 0.25s cubic-bezier(0.34, 1.56, 0.64, 1)",
        }}
        className="absolute left-0 top-0 select-none rounded-full border border-white/15 bg-velvet-light px-6 py-3 font-body text-sm font-medium text-ash shadow-md hover:bg-velvet-light active:scale-95 cursor-pointer whitespace-nowrap"
        onMouseEnter={dodge}
        onTouchStart={(e) => {
          e.preventDefault();
          dodge();
        }}
        onClick={(e) => {
          e.preventDefault();
          dodge();
        }}
        aria-label="Кнопка отказа уклоняется — этот вариант недоступен"
      >
        {labels[labelIndex % labels.length]}
        {dodgeCount > 5 && " 🙈"}
      </button>
    </div>
  );
}
