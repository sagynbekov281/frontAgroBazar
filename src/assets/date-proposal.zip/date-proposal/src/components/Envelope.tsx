import { useState } from "react";
import { FaHeart } from "react-icons/fa";

export default function Envelope({ onOpen }: { onOpen: () => void }) {
  const [opening, setOpening] = useState(false);

  const handleOpen = () => {
    if (opening) return;
    setOpening(true);
    window.setTimeout(onOpen, 650);
  };

  return (
    <div className="flex min-h-screen flex-col items-center justify-center px-6">
      <button
        type="button"
        onClick={handleOpen}
        className="group flex flex-col items-center gap-6"
        aria-label="Открыть письмо"
      >
        <div
          className={`relative flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-blush to-gold shadow-[0_0_30px_rgba(232,199,126,0.4)] transition-transform duration-300 group-hover:scale-105 ${
            opening ? "animate-[seal-crack_0.6s_ease-in_forwards]" : ""
          }`}
        >
          <FaHeart className="text-2xl text-ink/70" />
        </div>
        <span className="font-display text-lg italic text-ash">
          нажми, чтобы открыть письмо
        </span>
      </button>
    </div>
  );
}
