import type { ProposalConfig } from "../types";

/**
 * Мы не используем сервер: вся конфигурация из админки "зашивается"
 * в параметр ссылки в виде base64 (unicode-safe), которую можно
 * просто отправить человеку. Открыв ссылку, страница расшифровывает
 * параметр и показывает персональное приглашение.
 */

function utf8ToBase64Url(str: string): string {
  const bytes = new TextEncoder().encode(str);
  let binary = "";
  bytes.forEach((b) => {
    binary += String.fromCharCode(b);
  });
  const base64 = btoa(binary);
  return base64.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function base64UrlToUtf8(b64url: string): string {
  let base64 = b64url.replace(/-/g, "+").replace(/_/g, "/");
  while (base64.length % 4) base64 += "=";
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return new TextDecoder().decode(bytes);
}

export function encodeConfig(config: ProposalConfig): string {
  return utf8ToBase64Url(JSON.stringify(config));
}

export function decodeConfig(payload: string): ProposalConfig | null {
  try {
    const json = base64UrlToUtf8(payload);
    const parsed = JSON.parse(json);
    if (typeof parsed !== "object" || parsed === null) return null;
    return parsed as ProposalConfig;
  } catch {
    return null;
  }
}

export function buildProposalUrl(config: ProposalConfig): string {
  const payload = encodeConfig(config);
  const { origin, pathname } = window.location;
  const base = origin + pathname.replace(/\/(admin)?$/, "/");
  return `${base}#/propose?d=${payload}`;
}
