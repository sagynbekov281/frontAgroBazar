import { useState } from "react";
import { FaCopy, FaCheck, FaExternalLinkAlt, FaHeart } from "react-icons/fa";
import { defaultConfig } from "../types";
import type { ProposalConfig } from "../types";
import { buildProposalUrl } from "../lib/encode";

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-medium uppercase tracking-wide text-ash">
        {label}
      </span>
      {children}
    </label>
  );
}

const inputClass =
  "w-full rounded-xl border border-white/10 bg-ink/50 px-4 py-2.5 text-sm text-parchment placeholder:text-ash/60 outline-none focus:border-gold focus:ring-2 focus:ring-gold/30";

export default function Admin() {
  const [config, setConfig] = useState<ProposalConfig>(defaultConfig);
  const [link, setLink] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const update = <K extends keyof ProposalConfig>(key: K, value: ProposalConfig[K]) => {
    setConfig((c) => ({ ...c, [key]: value }));
    setLink(null);
  };

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    setLink(buildProposalUrl(config));
    setCopied(false);
  };

  const handleCopy = async () => {
    if (!link) return;
    try {
      await navigator.clipboard.writeText(link);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // clipboard недоступен — пользователь скопирует вручную
    }
  };

  return (
    <main className="min-h-screen bg-ink px-4 py-10 sm:px-6">
      <div className="mx-auto max-w-2xl">
        <div className="mb-8 flex items-center gap-3">
          <FaHeart className="text-xl text-blush" />
          <div>
            <h1 className="font-display text-2xl font-medium text-gold-soft">
              Собери приглашение
            </h1>
            <p className="text-sm text-ash">
              Заполни детали свидания — получишь личную ссылку, которую можно отправить.
              Никакой сервер данные не хранит: всё зашифровано прямо в ссылке.
            </p>
          </div>
        </div>

        <form onSubmit={handleGenerate} className="space-y-5 rounded-3xl border border-white/10 bg-velvet/60 p-6 sm:p-8">
          <div className="grid gap-5 sm:grid-cols-2">
            <Field label="Имя получателя">
              <input
                className={inputClass}
                value={config.recipientName}
                onChange={(e) => update("recipientName", e.target.value)}
                placeholder="Например, Аня"
              />
            </Field>
            <Field label="Твоё имя">
              <input
                className={inputClass}
                value={config.senderName}
                onChange={(e) => update("senderName", e.target.value)}
                placeholder="Например, Максим"
              />
            </Field>
          </div>

          <Field label="Вступление">
            <textarea
              className={inputClass}
              rows={2}
              value={config.intro}
              onChange={(e) => update("intro", e.target.value)}
              placeholder="Пара тёплых слов перед вопросом"
            />
          </Field>

          <Field label="Главный вопрос">
            <input
              required
              className={inputClass}
              value={config.question}
              onChange={(e) => update("question", e.target.value)}
              placeholder="Пойдёшь со мной на свидание?"
            />
          </Field>

          <div className="grid gap-5 sm:grid-cols-2">
            <Field label="Дата свидания">
              <input
                type="date"
                className={inputClass}
                value={config.date}
                onChange={(e) => update("date", e.target.value)}
              />
            </Field>
            <Field label="Время (необязательно)">
              <input
                type="time"
                className={inputClass}
                value={config.time}
                onChange={(e) => update("time", e.target.value)}
              />
            </Field>
          </div>

          <Field label="Место">
            <input
              className={inputClass}
              value={config.place}
              onChange={(e) => update("place", e.target.value)}
              placeholder="Например, кофейня на набережной"
            />
          </Field>

          <Field label="Сообщение после согласия">
            <textarea
              className={inputClass}
              rows={3}
              value={config.message}
              onChange={(e) => update("message", e.target.value)}
              placeholder="Что-то личное — план вечера, почему это место, что взять с собой"
            />
          </Field>

          <div className="grid gap-5 sm:grid-cols-2">
            <Field label="Текст кнопки согласия">
              <input
                className={inputClass}
                value={config.yesText}
                onChange={(e) => update("yesText", e.target.value)}
              />
            </Field>
            <Field label="Текст кнопки отказа (она всё равно убегает)">
              <input
                className={inputClass}
                value={config.noText}
                onChange={(e) => update("noText", e.target.value)}
              />
            </Field>
          </div>

          <button
            type="submit"
            className="w-full rounded-full bg-gradient-to-r from-gold to-blush py-3 text-sm font-semibold text-ink shadow-lg transition-transform hover:scale-[1.01] active:scale-95"
          >
            Создать ссылку на приглашение
          </button>
        </form>

        {link && (
          <div className="mt-6 rounded-2xl border border-gold/30 bg-ink/60 p-5">
            <p className="mb-3 text-xs uppercase tracking-wide text-ash">
              Готово — отправь эту ссылку
            </p>
            <div className="flex flex-col gap-3 sm:flex-row">
              <input
                readOnly
                value={link}
                className="w-full flex-1 rounded-xl border border-white/10 bg-velvet/60 px-4 py-2.5 text-xs text-parchment"
                onFocus={(e) => e.currentTarget.select()}
              />
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={handleCopy}
                  className="flex items-center gap-2 rounded-xl bg-gold px-4 py-2.5 text-sm font-semibold text-ink"
                >
                  {copied ? <FaCheck /> : <FaCopy />}
                  {copied ? "Скопировано" : "Копировать"}
                </button>
                <a
                  href={link}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-2 rounded-xl border border-white/15 px-4 py-2.5 text-sm text-parchment"
                >
                  <FaExternalLinkAlt className="text-xs" />
                  Открыть
                </a>
              </div>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
