import { Link } from "react-router-dom";
import { FaHeart, FaArrowRight } from "react-icons/fa";
import AmbientDrift from "../components/AmbientDrift";

export default function Home() {
  return (
    <main className="relative flex min-h-screen items-center justify-center overflow-hidden bg-ink px-6">
      <AmbientDrift count={14} />
      <div className="relative flex max-w-md flex-col items-center text-center">
        <FaHeart className="mb-5 text-3xl text-blush" />
        <h1 className="mb-3 font-display text-3xl font-medium leading-tight text-gold-soft sm:text-4xl">
          Спроси. Красиво.
        </h1>
        <p className="mb-8 text-sm leading-relaxed text-ash">
          Собери личное приглашение на свидание за пару минут: дата, место
          и тёплые слова — а кнопка «нет» пусть побегает.
        </p>
        <Link
          to="/admin"
          className="flex items-center gap-2 rounded-full bg-gradient-to-r from-gold to-blush px-7 py-3 text-sm font-semibold text-ink shadow-lg transition-transform hover:scale-105 active:scale-95"
        >
          Создать приглашение
          <FaArrowRight className="text-xs" />
        </Link>
      </div>
    </main>
  );
}
