import { useMemo, useState } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { FaCalendarAlt, FaMapMarkerAlt, FaHeart } from "react-icons/fa";
import { decodeConfig } from "../lib/encode";
import type { ProposalConfig } from "../types";
import DodgeButton from "../components/DodgeButton";
import AmbientDrift from "../components/AmbientDrift";
import Envelope from "../components/Envelope";

const NO_LABELS = [
  "Нет",
  "Точно нет?",
  "Даже не пытайся",
  "Мимо 😏",
  "Не сегодня",
  "Всё равно нет",
  "Ты быстрый, но я быстрее",
  "Попробуй ещё раз",
];

function formatDate(date: string): string {
  if (!date) return "";
  try {
    const d = new Date(date + "T00:00:00");
    return new Intl.DateTimeFormat("ru-RU", {
      day: "numeric",
      month: "long",
      year: "numeric",
    }).format(d);
  } catch {
    return date;
  }
}

function FallingHearts() {
  const hearts = useMemo(
    () =>
      Array.from({ length: 24 }, (_, i) => ({
        id: i,
        left: Math.random() * 100,
        delay: Math.random() * 2,
        duration: 3 + Math.random() * 3,
        size: 12 + Math.random() * 14,
      })),
    []
  );
  return (
    <div className="pointer-events-none fixed inset-0 overflow-hidden">
      {hearts.map((h) => (
        <FaHeart
          key={h.id}
          style={{
            left: `${h.left}%`,
            top: "-5%",
            animation: `fall ${h.duration}s linear ${h.delay}s infinite`,
            fontSize: h.size,
          }}
          className="absolute text-blush/80"
        />
      ))}
    </div>
  );
}

function Invalid() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 px-6 text-center">
      <p className="font-display text-2xl text-parchment">
        Похоже, это письмо потерялось по дороге.
      </p>
      <p className="max-w-sm text-sm text-ash">
        Ссылка неполная или повреждена. Попроси того, кто её отправил,
        прислать её ещё раз — либо создай новое приглашение сам.
      </p>
      <Link
        to="/admin"
        className="mt-2 rounded-full bg-gold px-5 py-2 text-sm font-semibold text-ink"
      >
        Создать приглашение
      </Link>
    </div>
  );
}

export default function Propose() {
  const [params] = useSearchParams();
  const payload = params.get("d");
  const config = useMemo<ProposalConfig | null>(
    () => (payload ? decodeConfig(payload) : null),
    [payload]
  );

  const [opened, setOpened] = useState(false);
  const [accepted, setAccepted] = useState(false);

  if (!config || !config.question) {
    return <Invalid />;
  }

  if (!opened) {
    return (
      <main className="relative min-h-screen bg-ink">
        <AmbientDrift />
        <Envelope onOpen={() => setOpened(true)} />
      </main>
    );
  }

  return (
    <main className="relative min-h-screen overflow-hidden bg-ink">
      <AmbientDrift />
      {accepted && <FallingHearts />}

      <div className="relative flex min-h-screen items-center justify-center px-4 py-10 sm:px-6">
        <div
          className="w-full max-w-md rounded-3xl border border-white/10 bg-velvet/80 p-6 shadow-2xl backdrop-blur sm:p-10"
          style={{ animation: "card-rise 0.7s ease-out" }}
        >
          {!accepted ? (
            <div className="flex flex-col items-center text-center">
              <span className="mb-3 text-xs uppercase tracking-[0.3em] text-ash">
                {config.senderName
                  ? `от ${config.senderName}`
                  : "личное сообщение"}
              </span>

              {config.recipientName && (
                <h1 className="mb-3 font-display text-3xl font-medium text-gold-soft">
                  {config.recipientName}
                </h1>
              )}

              <p className="mb-6 text-sm leading-relaxed text-ash">
                {config.intro}
              </p>

              <h2 className="mb-8 font-display text-2xl italic leading-snug text-parchment sm:text-3xl">
                {config.question}
              </h2>

              <div className="mb-2 flex w-full flex-col items-center gap-4 sm:flex-row sm:justify-center">
                <button
                  type="button"
                  onClick={() => setAccepted(true)}
                  className="w-full rounded-full bg-gradient-to-r from-gold to-blush px-8 py-3 font-body text-base font-semibold text-ink shadow-lg transition-transform hover:scale-105 active:scale-95 sm:w-auto"
                  style={{ animation: "gentle-glow 2.4s ease-in-out infinite" }}
                >
                  {config.yesText || "Да"}
                </button>

                <DodgeButton labels={[config.noText || "Нет", ...NO_LABELS]} className="sm:w-40" />
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center text-center">
              <FaHeart className="mb-4 text-4xl text-blush" />
              <h2 className="mb-2 font-display text-2xl font-medium text-gold-soft">
                Она сказала «{config.yesText || "да"}»! 💫
              </h2>
              <p className="mb-6 text-sm text-ash">
                Вот детали вашего свидания:
              </p>

              <div className="mb-6 w-full space-y-3 rounded-2xl bg-ink/40 p-5 text-left">
                {config.date && (
                  <div className="flex items-center gap-3 text-sm text-parchment">
                    <FaCalendarAlt className="shrink-0 text-gold" />
                    <span>
                      {formatDate(config.date)}
                      {config.time ? `, ${config.time}` : ""}
                    </span>
                  </div>
                )}
                {config.place && (
                  <div className="flex items-center gap-3 text-sm text-parchment">
                    <FaMapMarkerAlt className="shrink-0 text-gold" />
                    <span>{config.place}</span>
                  </div>
                )}
              </div>

              {config.message && (
                <p className="whitespace-pre-line text-sm leading-relaxed text-ash">
                  {config.message}
                </p>
              )}
            </div>
          )}
        </div>
      </div>
    </main>
  );
}
