export interface ProposalConfig {
  /** Имя того, кому адресовано приглашение */
  recipientName: string;
  /** Имя того, кто отправляет приглашение */
  senderName: string;
  /** Главный вопрос, например "Пойдёшь со мной на свидание?" */
  question: string;
  /** Короткое тёплое вступление перед вопросом */
  intro: string;
  /** Дата свидания (YYYY-MM-DD) */
  date: string;
  /** Время свидания (HH:MM), необязательно */
  time?: string;
  /** Место свидания */
  place: string;
  /** Личное сообщение / подробности плана */
  message: string;
  /** Текст на кнопке согласия */
  yesText: string;
  /** Текст на кнопке отказа (она всё равно будет убегать) */
  noText: string;
}

export const defaultConfig: ProposalConfig = {
  recipientName: "",
  senderName: "",
  question: "Пойдёшь со мной на свидание?",
  intro: "У меня есть один вопрос, который я давно хотел(а) задать...",
  date: "",
  time: "",
  place: "",
  message: "",
  yesText: "Да",
  noText: "Нет",
};
